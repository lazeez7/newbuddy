import React from 'react';
import { Swiper, SwiperSlide } from 'swiper/react';

import './basic.css';

const Basic = () => {
  return <></>;
};

export default Basic;
